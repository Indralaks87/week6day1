package week6day1assignment;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.Test;

import io.github.sukgu.Shadow;

public class AssignIncident extends BaseIncident {
    @Test(priority=2)
	public void assignIns() throws InterruptedException {
		
		
		WebElement findElement = driver.findElement(By.xpath("//input[@class='form-control']"));
		findElement.sendKeys("INC0010085");
		findElement.sendKeys(Keys.ENTER);
		
		driver.findElement(By.xpath("//a[text()='INC0010085']")).click();
		driver.findElement(By.xpath("//span[@class='input-group-btn']")).click();
		Set<String> oldWindow = driver.getWindowHandles();
        List<String> newWindow = new ArrayList<String>(oldWindow);
        driver.switchTo().window(newWindow.get(1));
		
	    WebElement findElement2 = driver.findElement(By.xpath("//input[@class='form-control']"));
	    findElement2.sendKeys("software");
	    findElement2.sendKeys(Keys.ENTER);
	    
	    driver.findElement(By.xpath("//a[text()='Software Manager']")).click();
	    driver.switchTo().window(newWindow.get(0));
		Thread.sleep(2000);
	
	
		driver.switchTo().frame(frame);	
	    driver.findElement(By.xpath("//button[@id='sysverb_update']")).click();
	    
	  
	    String text = driver.findElement(By.xpath("//div[@class='list2_empty-state-list']")).getText();
	    if(text.contains("No records to display")) {
	    	System.out.println("Assigned group is present");
	    }
	    else {
	    	System.out.println("Assigned group is not present");
	    	
	    }
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
	
	
}	
	
		