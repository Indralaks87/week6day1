package week6day1assignment;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import io.github.sukgu.Shadow;

public class UpdateIncident extends BaseIncident {

	@Test(priority=1)
	public void updateIns() throws InterruptedException  {
		
	
		
		WebElement findElement = driver.findElement(By.xpath("//input[@class='form-control']"));
		findElement.sendKeys("INC0008111");
		findElement.sendKeys(Keys.ENTER);
		
		driver.findElement(By.xpath("//a[text()='INC0008111']")).click();
		WebElement urgency = driver.findElement(By.xpath("//select[@id='incident.urgency']"));
		Select highDD = new Select(urgency);
		highDD.selectByIndex(0);
		
		WebElement state = driver.findElement(By.xpath("//select[@id='incident.state']"));
		Select progressDD = new Select(state);
		progressDD.selectByIndex(1);
		
		driver.findElement(By.xpath("//button[@id='sysverb_update']")).click();
		driver.findElement(By.xpath("//a[text()='INC0008111']")).click();
		
		String incident = driver.findElement(By.xpath("//span[@class='sn-widget-list-table-cell']/following-sibling::span")).getText();
		System.out.println("Verify IncidentSate :" +incident);
		
		String text2 = driver.findElement(By.xpath("(//span[@class='sn-widget-list-table-cell']/following-sibling::span)[4]")).getText();
		System.out.println("Verify Priority :"+text2);
		
		
		
		
		
		
		
		
		
		
		
		
	}
	
	
}	
	
		