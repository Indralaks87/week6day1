package week6day1assignment;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import io.github.sukgu.Shadow;

public class CreateIncident extends BaseIncident{

	@Test(priority=0)
	public  void createIns() throws InterruptedException {
		
		
		driver.findElement(By.xpath("//button[text()='New']")).click();
		
		
		String incidentNo = driver.findElement(By.xpath("//input[@id='incident.number']")).getAttribute("value");
		System.out.println("The Incident Number :"+incidentNo);
		
		String text = driver.findElement(By.xpath("//input[@id='sys_display.incident.caller_id']")).getAttribute("value");
		System.out.println(text);
		driver.findElement(By.xpath("//input[@id='incident.short_description']")).sendKeys("Create new Instance Record");
		
		driver.findElement(By.xpath("//button[text()='Submit']")).click();
		String text2 = driver.findElement(By.linkText(incidentNo)).getText();
		if(incidentNo.equalsIgnoreCase(text2)) {
			System.out.println("Instance number is same");
		}
		else {
			System.out.println("Instance number is not same");
			
			
		}
		
		
	}	
		
		
		
}


