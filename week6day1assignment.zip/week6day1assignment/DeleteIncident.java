package week6day1assignment;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import io.github.sukgu.Shadow;

public class DeleteIncident extends BaseIncident {
     @Test(priority=3)
	public void delIns() throws InterruptedException {
		
		
		WebElement findElement = driver.findElement(By.xpath("//input[@class='form-control']"));
		findElement.sendKeys("INC0010083");
		findElement.sendKeys(Keys.ENTER);
		
		driver.findElement(By.xpath("//a[text()='INC0010083']")).click();
		driver.findElement(By.xpath("//button[text()='Delete']")).click();
		driver.findElement(By.xpath("//button[@id='ok_button']")).click();
		
		
		String text = driver.findElement(By.xpath("//div[@class='list2_empty-state-list']")).getText();
	    if(text.contains("No records to display")) {
	    	System.out.println("The incident is deleted");
	    }
	    else {
	    	System.out.println("The incident is not deleted");
	    	
	    }
		
		
		
		
		
		
		
		
		
	}
	
	
}	
	
		