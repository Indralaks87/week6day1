package week6day1assignment;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class DeletefindLead extends Base{
    @Test
	public  void runDelete() throws InterruptedException {
		
		
        driver.findElement(By.linkText("Find Leads")).click();
        driver.findElement(By.xpath("//span[text()='Phone']")).click();
        driver.findElement(By.xpath("//input[@name='phoneNumber']")).sendKeys("99");
        driver.findElement(By.xpath("//button[text()='Find Leads']")).click();
        WebElement text = driver.findElement(By.linkText("11798"));
        System.out.println(text);
        Thread.sleep(2000);
        driver.findElement(By.xpath("(//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a)[1]")).click();
        driver.findElement(By.xpath("//a[text()='Delete']")).click();
        driver.findElement(By.linkText("Find Leads")).click();
        driver.findElement(By.name("id")).sendKeys("11798");
        driver.findElement(By.xpath("//button[text()='Find Leads']")).click();
        //driver.close();
        
        
        
        
        
        
        
    
        
        
	}

}
