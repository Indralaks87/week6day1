package week6day1assignment;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeDriverService;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import io.github.sukgu.Shadow;

public class BaseIncident {
	
	public ChromeDriver driver;
	public WebElement frame;
	
	@BeforeMethod
	public void preCondition() throws InterruptedException {
		
	ChromeOptions options = new ChromeOptions();
	options.addArguments("--remote-allow-origins=*");
	 
	driver = new ChromeDriver(options);
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	
	driver.get(" https://dev57841.service-now.com/");
	driver.findElement(By.id("user_name")).sendKeys("admin");
	driver.findElement(By.id("user_password")).sendKeys("Srivatsan@12");
	driver.findElement(By.id("sysverb_login")).click();
	
	Shadow dom = new Shadow(driver);
	dom.setImplicitWait(20);
	dom.findElementByXPath("//div[text()='All']").click();
	dom.setImplicitWait(10);
	WebElement findElementByXPath = dom.findElementByXPath("//input[@id='filter']");
	findElementByXPath.sendKeys("Incident");
	dom.findElementByXPath("//mark[contains(text(),'Inciden')]").click();
	WebElement frame = dom.findElementByXPath("//iframe[@title='Main Content']");
	driver.switchTo().frame(frame);		
	Thread.sleep(1000);
	
	

    }
  
   @AfterMethod
   public void postCondition() {
	  
	  driver.close();
	  
  }

}
